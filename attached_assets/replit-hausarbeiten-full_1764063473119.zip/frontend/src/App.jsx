import React, {useEffect, useState} from 'react';
import axios from 'axios';
const api = axios.create({baseURL:'http://localhost:8000/api'});
function App(){
  const [user,setUser]=useState(null);
  const [token,setToken]=useState("");
  const [tasks,setTasks]=useState([]);
  const [acceptances,setAcceptances]=useState([]);
  const [form,setForm]=useState({title:"Staubsaugen",description:"Wohnzimmer saugen",sats:50,parent_id:1});
  useEffect(()=>{fetchTasks();fetchAcceptances();},[]);
  async function login(name,password){
    const r=await api.post("/login",{name,password});
    setToken(r.data.token); setUser(r.data);
  }
  async function fetchTasks(){ const r=await api.get("/tasks"); setTasks(r.data); }
  async function fetchAcceptances(){ const r=await api.get("/acceptances"); setAcceptances(r.data); }
  async function createTask(e){e.preventDefault();await api.post("/tasks",form);fetchTasks();}
  async function acceptTask(task_id){await api.post("/tasks/accept",{task_id,child_id:2});fetchTasks();fetchAcceptances();}
  async function uploadProof(id,file){const fd=new FormData();fd.append("file",file);await api.post(`/tasks/${id}/submit`,fd,{headers:{'Content-Type':'multipart/form-data'}});fetchTasks();fetchAcceptances();}
  async function approve(id){await api.post(`/tasks/${id}/approve`);fetchTasks();fetchAcceptances();}
  if(!user)return(<div><h2>Login</h2><button onClick={()=>login("Mama","1234")}>Login Mama</button><button onClick={()=>login("Luca","abcd")}>Login Luca</button></div>);
  return(<div style={{padding:20,fontFamily:"Arial"}}><h1>Hausarbeiten App</h1>
  {user.role==="parent" && <div><h2>Eltern Dashboard</h2>
    <form onSubmit={createTask}><input placeholder="Titel" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/><br/>
    <input placeholder="Beschreibung" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><br/>
    <input placeholder="Sats" type="number" value={form.sats} onChange={e=>setForm({...form,sats:parseInt(e.target.value||0)})}/><br/>
    <button type="submit">Aufgabe anlegen</button></form>
    <h3>Offene Aufgaben</h3>{tasks.map(t=><div key={t.id}>{t.title} ({t.sats} sats) - {t.status} {t.status==="submitted"&&<button onClick={()=>approve(t.id)}>Genehmigen</button>}</div>)}
  </div>}
  {user.role==="child" && <div><h2>Kind Dashboard</h2>{tasks.filter(t=>t.status==="open").map(t=><div key={t.id}>{t.title} ({t.sats} sats) <button onClick={()=>acceptTask(t.id)}>Annehmen</button></div>)}
  <h3>Meine Aufgaben</h3>{acceptances.map(a=><div key={a.id}>{a.task_id} - {a.payout_status||"offen"} {a.proof_file? <a href={`http://localhost:8000/uploads/${a.proof_file}`} target="_blank">Beweis</a>: <input type="file" onChange={e=>uploadProof(a.id,e.target.files[0])}/>}</div>)}</div>}
  </div>);
}
export default App;
