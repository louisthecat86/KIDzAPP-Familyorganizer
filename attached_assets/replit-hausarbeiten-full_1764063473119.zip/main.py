from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Form
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlmodel import SQLModel, Field, create_engine, Session, select
from pydantic import BaseModel
from typing import Optional, List
import uuid, os, time, hashlib, hmac, base64, json, requests

# --- Config ---
DATABASE_URL = "sqlite:///./data.db"
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
LNBITS_MOCK_URL = "/lnbits/mock"  # Mock endpoint

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
app = FastAPI(title="Hausarbeiten App")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- DB Models ---
class User(SQLModel, table=True):
    id: Optional[int]=Field(default=None, primary_key=True)
    name: str
    role: str  # 'parent' or 'child'
    password: str

class Task(SQLModel, table=True):
    id: Optional[int]=Field(default=None, primary_key=True)
    title: str
    description: Optional[str]=None
    sats: int=0
    status: str="open"  # open, in_progress, submitted, approved, rejected
    parent_id: Optional[int]=None

class TaskAcceptance(SQLModel, table=True):
    id: Optional[int]=Field(default=None, primary_key=True)
    task_id: int
    child_id: int
    accepted_at: Optional[float]=None
    proof_file: Optional[str]=None
    submitted_at: Optional[float]=None
    parent_reviewed_at: Optional[float]=None
    payout_status: Optional[str]=None  # pending, paid, failed

# --- Auth ---
def fake_hash(pw): return pw+"123"
def verify_pw(pw, hashed): return fake_hash(pw)==hashed

# --- Init DB ---
def init_db():
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        if not s.exec(select(User)).all():
            s.add(User(name="Mama", role="parent", password=fake_hash("1234")))
            s.add(User(name="Luca", role="child", password=fake_hash("abcd")))
            s.commit()
init_db()

# --- Auth endpoints ---
class LoginPayload(BaseModel):
    name: str
    password: str

@app.post("/api/login")
def login(payload: LoginPayload):
    with Session(engine) as s:
        user = s.exec(select(User).where(User.name==payload.name)).first()
        if user and verify_pw(payload.password, user.password):
            # naive token = base64(name:role)
            token = base64.b64encode(f"{user.name}:{user.role}".encode()).decode()
            return {"token": token, "role": user.role, "name": user.name, "id": user.id}
        raise HTTPException(status_code=401, detail="Invalid credentials")

def get_current_user(token: str = Form(...)):
    try:
        decoded = base64.b64decode(token).decode()
        name, role = decoded.split(":")
        with Session(engine) as s:
            user = s.exec(select(User).where(User.name==name)).first()
            if user: return user
    except: pass
    raise HTTPException(status_code=401, detail="Invalid token")

# --- Task Endpoints ---
class TaskCreate(BaseModel):
    title: str
    description: Optional[str]
    sats: int
    parent_id: int

@app.post("/api/tasks")
def create_task(payload: TaskCreate):
    t = Task(title=payload.title, description=payload.description, sats=payload.sats, parent_id=payload.parent_id)
    with Session(engine) as s:
        s.add(t); s.commit(); s.refresh(t)
        return t

@app.get("/api/tasks", response_model=List[Task])
def get_tasks():
    with Session(engine) as s:
        return s.exec(select(Task)).all()

class AcceptTaskPayload(BaseModel):
    task_id: int
    child_id: int

@app.post("/api/tasks/accept")
def accept_task(payload: AcceptTaskPayload):
    with Session(engine) as s:
        task = s.get(Task, payload.task_id)
        if not task or task.status!="open":
            raise HTTPException(status_code=400, detail="Task not open")
        ta = TaskAcceptance(task_id=task.id, child_id=payload.child_id, accepted_at=time.time())
        task.status="in_progress"
        s.add(ta); s.add(task); s.commit(); s.refresh(ta)
        return ta

@app.post("/api/tasks/{accept_id}/submit")
async def submit_proof(accept_id:int, file:UploadFile=File(...)):
    with Session(engine) as s:
        ta = s.get(TaskAcceptance, accept_id)
        if not ta: raise HTTPException(status_code=404, detail="Acceptance not found")
        fname=f"{uuid.uuid4().hex}_{file.filename}"
        fpath=os.path.join(UPLOAD_DIR, fname)
        with open(fpath,"wb") as f: f.write(await file.read())
        ta.proof_file=fname
        ta.submitted_at=time.time()
        task=s.get(Task, ta.task_id)
        task.status="submitted"
        s.add(ta); s.add(task); s.commit(); s.refresh(ta)
        return {"acceptance":ta.id, "proof_file":fname}

@app.post("/api/tasks/{accept_id}/approve")
def approve_task(accept_id:int):
    with Session(engine) as s:
        ta=s.get(TaskAcceptance, accept_id)
        if not ta: raise HTTPException(status_code=404, detail="Acceptance not found")
        if ta.payout_status=="paid": raise HTTPException(status_code=400, detail="Already paid")
        task=s.get(Task, ta.task_id)
        payload={"amount_sats":task.sats,"to_child_id":ta.child_id,"memo":f"Belohnung: {task.title}"}
        try:
            resp = requests.post(LNBITS_MOCK_URL, json=payload, timeout=5)
            resp.raise_for_status()
            data=resp.json()
            ta.payout_status="paid" if data.get("status")=="ok" else "failed"
        except: ta.payout_status="failed"
        ta.parent_reviewed_at=time.time()
        task.status="approved" if ta.payout_status=="paid" else "submitted"
        s.add(ta); s.add(task); s.commit(); s.refresh(ta)
        return {"payout_status":ta.payout_status}

@app.get("/api/acceptances", response_model=List[TaskAcceptance])
def list_acceptances():
    with Session(engine) as s:
        return s.exec(select(TaskAcceptance)).all()

# --- Mock LNbits ---
@app.post("/lnbits/mock")
def lnbits_mock(payload: dict):
    return {"status":"ok", "txid":f"mock_{uuid.uuid4().hex}", "amount":payload.get("amount_sats")}

# --- File serve ---
@app.get("/uploads/{filename}")
def get_upload(filename:str):
    path=os.path.join(UPLOAD_DIR, filename)
    if not os.path.exists(path): raise HTTPException(status_code=404)
    return FileResponse(path)

# --- Serve frontend ---
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
